from django.shortcuts import render

# funcion que recibe un parametro request y retorna un html
def index_aplicacion_tarea1(request):
    return render(request,"index.html")#aqui va nombre de template, 
#pero como ya lo agregamos a setting, solo poner nombre de archivo.
